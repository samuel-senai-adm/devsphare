<?php session_start(); /* if (!isset($_SESSION['usuario'])) { header("Location: login.php"); exit; } */
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}
$usuario = $_SESSION['usuario_nome']; ?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartLocker - Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>
    <aside class="sidebar">
        <div class="logo"> <i class="fas fa-box"></i>
            <h2>SmartLocker</h2>
        </div>
        <nav> <a href="#" class="active"> <i class="fas fa-chart-line"></i> Dashboard </a> <a href="#"> <i class="fas fa-diagram-project"></i> Projetos </a> <a href="#"> <i class="fas fa-list-check"></i> Kanban </a> <a href="#"> <i class="fas fa-users"></i> Equipe </a> <a href="#"> <i class="fas fa-microchip"></i> RFID </a> <a href="#"> <i class="fas fa-user-tie"></i> Clientes </a> <a href="#"> <i class="fas fa-file-lines"></i> Relatórios </a> </nav> <a href="logout.php" class="logout"> <i class="fas fa-right-from-bracket"></i> Sair </a>
    </aside>
    <main class="main">
        <header>
            <div>
                <h1>Bem-vindo, <?= htmlspecialchars($usuario) ?></h1>
                <p>Painel de gerenciamento SmartLocker</p>
            </div>
            <div class="perfil"> <i class="fas fa-user-circle"></i> </div>
        </header>
        <section class="cards">
            <div class="card"> <i class="fas fa-list"></i>
                <h3>32</h3>
                <p>Tarefas</p>
            </div>
            <div class="card"> <i class="fas fa-spinner"></i>
                <h3>8</h3>
                <p>Em andamento</p>
            </div>
            <div class="card"> <i class="fas fa-check-circle"></i>
                <h3>24</h3>
                <p>Concluídas</p>
            </div>
            <div class="card"> <i class="fas fa-users"></i>
                <h3>4</h3>
                <p>Membros</p>
            </div>
        </section>
        <section class="kanban">
            <div class="column">
                <h2>Ideias</h2>
                <div class="task"> Definir RFID </div>
                <div class="task"> Planejar app mobile </div>
            </div>
            <div class="column">
                <h2>Pesquisa</h2>
                <div class="task"> Estudo ESP32 </div>
            </div>
            <div class="column">
                <h2>Desenvolvimento</h2>
                <div class="task"> Sistema de login </div>
                <div class="task"> Dashboard </div>
            </div>
            <div class="column">
                <h2>Concluído</h2>
                <div class="task"> Levantamento de requisitos </div>
            </div>
        </section>
    </main>
</body>

</html>