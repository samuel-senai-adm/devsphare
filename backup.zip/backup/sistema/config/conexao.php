<?php

// produção
$host = "localhost";
$user = "devsphar_root";
$password = "59FYz7reQTexEyw";
$database = "devsphar_smartlocker";

// local
// $host = "10.140.170.57";
// $user = "root";
// $password = "123456";
// $database = "smartlocker";
// $port = "3307";

// produção
$conn = new mysqli($host, $user, $password, $database);

// local
// $conn = new mysqli($host, $user, $password, $database, $port);

if($conn->connect_error){
    die("Erro na conexão");
}

?>