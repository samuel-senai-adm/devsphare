<?php

// produção
// $host = "localhost";
// $user = "devsphar_root";
// $password = "59FYz7reQTexEyw";
// $database = "devsphar_smartlocker";

// local
$host = "10.140.169.32";
$user = "root";
$password = "123456";
$database = "devsphar_smartlocker";
$port = "3306";

// produção
$conn = new mysqli($host, $user, $password, $database, $port);

// local
// $conn = new mysqli($host, $user, $password, $database, $port);

if($conn->connect_error){
    die("Erro na conexão");
}

?>